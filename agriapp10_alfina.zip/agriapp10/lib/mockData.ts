// ── Mock Data Lokal (dipakai saat API belum tersedia) ──────────────
// Ganti fetch ke API asli nanti, struktur data sudah disesuaikan dengan format Yii2

export const MOCK_LANDS = [
  {
    id: 1,
    land_name: "Lahan Babakan Sari",
    farmer_name: "Brahim",
    farmer_id: 1,
    commodity_name: "Kakao",
    commodity_id: 2,
    total_area_hectares: "22.98",
    latitude: -6.9147,
    longitude: 107.6098,
    has_polygon: true,
    polygon_path: JSON.stringify([
      [-6.913, 107.608], [-6.913, 107.612], [-6.916, 107.612], [-6.916, 107.608]
    ]),
    eudr_status: "Compliant",
    created_at: "2024-01-10",
  },
  {
    id: 2,
    land_name: "Lahan Bos",
    farmer_name: "Brahim",
    farmer_id: 1,
    commodity_name: "Kakao",
    commodity_id: 2,
    total_area_hectares: "122.99",
    latitude: -6.9200,
    longitude: 107.6150,
    has_polygon: false,
    polygon_path: "[]",
    eudr_status: "Non-Compliant",
    created_at: "2024-02-05",
  },
  {
    id: 3,
    land_name: "Sawah Blok Utara",
    farmer_name: "Brahim",
    farmer_id: 1,
    commodity_name: "Kopi",
    commodity_id: 1,
    total_area_hectares: "12.35",
    latitude: -6.9080,
    longitude: 107.6200,
    has_polygon: true,
    polygon_path: JSON.stringify([
      [-6.907, 107.619], [-6.907, 107.622], [-6.910, 107.622], [-6.910, 107.619]
    ]),
    eudr_status: "Non-Compliant",
    created_at: "2024-03-01",
  },
  {
    id: 4,
    land_name: "Lahan B4112",
    farmer_name: "Brahim",
    farmer_id: 1,
    commodity_name: "Kopi",
    commodity_id: 1,
    total_area_hectares: "46.00",
    latitude: -6.9250,
    longitude: 107.6050,
    has_polygon: false,
    polygon_path: "[]",
    eudr_status: "Non-Compliant",
    created_at: "2024-03-15",
  },
];

export const MOCK_DOCUMENTS: Record<number, any[]> = {
  1: [
    { id: 1, land_id: 1, doc_name: "Sertifikat Tanah", doc_type: "Sertifikat", file_url: "#", uploaded_at: "2024-04-01", status: "Verified" },
    { id: 2, land_id: 1, doc_name: "Izin Usaha Perkebunan", doc_type: "Izin", file_url: "#", uploaded_at: "2024-04-10", status: "Pending" },
  ],
  2: [],
  3: [
    { id: 3, land_id: 3, doc_name: "SK Deforestasi 2021", doc_type: "SK", file_url: "#", uploaded_at: "2024-05-01", status: "Verified" },
  ],
  4: [],
};

export const MOCK_PLANTING_CYCLES: Record<number, any[]> = {
  1: [
    {
      id: 1, land_id: 1, commodity: "Kakao", phase: "Panen",
      planting_date: "2023-01-15", harvest_date: "2024-01-15",
      notes: "Hasil panen baik, cuaca mendukung",
      activities: [
        { id: 1, cycle_id: 1, type: "Pengairan", date: "2023-02-01", cost: 150000, note: "Irigasi rutin" },
        { id: 2, cycle_id: 1, type: "Pemupukan", date: "2023-03-10", cost: 320000, note: "Pupuk NPK" },
        { id: 3, cycle_id: 1, type: "Penanganan Hama", date: "2023-05-20", cost: 200000, note: "Semprot insektisida" },
        { id: 4, cycle_id: 1, type: "Panen", date: "2024-01-15", cost: 0, note: "Panen perdana 2.1 ton" },
      ]
    },
    {
      id: 2, land_id: 1, commodity: "Kakao", phase: "Perawatan",
      planting_date: "2024-02-01", harvest_date: null,
      notes: "Siklus kedua, bibit unggul",
      activities: [
        { id: 5, cycle_id: 2, type: "Pengairan", date: "2024-03-01", cost: 175000, note: "Sistem drip" },
      ]
    }
  ],
  2: [],
  3: [
    {
      id: 3, land_id: 3, commodity: "Kopi", phase: "Perawatan",
      planting_date: "2023-06-01", harvest_date: null,
      notes: "Kopi arabika premium",
      activities: [
        { id: 6, cycle_id: 3, type: "Pemupukan", date: "2023-07-15", cost: 280000, note: "Pupuk organik" },
      ]
    }
  ],
  4: [],
};

export const MOCK_HARVEST_TRACES: Record<number, any[]> = {
  1: [
    {
      id: 1, land_id: 1, harvest_date: "2024-01-15", commodity: "Kakao",
      volume_kg: 2100, destination: "Exporter PT Maju Jaya",
      eudr_compliant: true, polygon_verified: true,
      doc_count: 2, cycle_id: 1,
      notes: "Produk siap ekspor ke pasar Eropa",
    }
  ],
  2: [],
  3: [],
  4: [],
};

export const MOCK_USER_PROFILE = {
  id: 1,
  full_name: "Brahim Santosa",
  username: "brahim",
  email: "brahim@agriapp.id",
  nik: "3204010101900001",
  phone: "081234567890",
  address: "Jl. Perkebunan No. 12, Bandung, Jawa Barat",
  user_level: "userfarmer",
};
