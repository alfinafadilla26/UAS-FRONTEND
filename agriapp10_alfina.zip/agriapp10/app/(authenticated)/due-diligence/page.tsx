"use client";

import { useEffect, useState } from "react";
import { MOCK_LANDS, MOCK_HARVEST_TRACES, MOCK_DOCUMENTS, MOCK_PLANTING_CYCLES } from "@/lib/mockData";

export default function DueDiligencePage() {
  const [token, setToken] = useState("");
  const [lands, setLands] = useState<any[]>([]);
  const [traces, setTraces] = useState<Record<number, any[]>>({});
  const [docs, setDocs] = useState<Record<number, any[]>>({});
  const [cycles, setCycles] = useState<Record<number, any[]>>({});
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedLand, setSelectedLand] = useState<any>(null);
  const [form, setForm] = useState({ harvest_date: "", volume_kg: "", destination: "", notes: "" });
  const [successMsg, setSuccessMsg] = useState("");
  const [viewDetail, setViewDetail] = useState<any>(null);

  useEffect(() => {
    const t = localStorage.getItem("access_token") || "";
    setToken(t);
    loadData(t);
  }, []);

  async function loadData(t: string) {
    setLoading(true);
    try {
      const res = await fetch("/api/proxy/land", { headers: { Authorization: `Bearer ${t}` } });
      if (res.ok) {
        const json = await res.json();
        const items = Array.isArray(json) ? json : json.data || [];
        setLands(items.length ? items : MOCK_LANDS);
      } else setLands(MOCK_LANDS);
    } catch { setLands(MOCK_LANDS); }
    setTraces(MOCK_HARVEST_TRACES);
    setDocs(MOCK_DOCUMENTS);
    setCycles(MOCK_PLANTING_CYCLES);
    setLoading(false);
  }

  async function handleAddTrace(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedLand) return;
    const landDocs = docs[selectedLand.id] || [];
    const landCycles = cycles[selectedLand.id] || [];
    const polyVerified = selectedLand.has_polygon === true || selectedLand.has_polygon === 1;
    const eudrOk = selectedLand.eudr_status === "Compliant";

    const newTrace = {
      id: Date.now(),
      land_id: selectedLand.id,
      harvest_date: form.harvest_date,
      commodity: selectedLand.commodity_name || "—",
      volume_kg: Number(form.volume_kg),
      destination: form.destination,
      eudr_compliant: eudrOk,
      polygon_verified: polyVerified,
      doc_count: landDocs.length,
      cycle_id: landCycles[0]?.id || null,
      notes: form.notes,
    };
    setTraces(prev => ({ ...prev, [selectedLand.id]: [...(prev[selectedLand.id] || []), newTrace] }));
    setShowModal(false);
    setForm({ harvest_date: "", volume_kg: "", destination: "", notes: "" });
    setSuccessMsg("✅ Data tracing hasil panen berhasil disimpan");
    setTimeout(() => setSuccessMsg(""), 3000);
  }

  const totalTraces = Object.values(traces).flat().length;
  const totalVolume = Object.values(traces).flat().reduce((s: number, t: any) => s + (t.volume_kg || 0), 0);
  const eudrReady = Object.values(traces).flat().filter((t: any) => t.eudr_compliant && t.polygon_verified && t.doc_count > 0).length;

  return (
    <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#064e3b,#047857,#10b981)", borderRadius: 16, padding: "28px 32px", marginBottom: 24, color: "#fff" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>📄</div>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>Document Tracing Hasil Panen</h2>
            <p style={{ margin: 0, fontSize: 13, color: "#a7f3d0" }}>Rekam jejak produk pertanian — syarat ekspor ke pasar Eropa (EUDR/CEPA)</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Rekaman Panen", val: totalTraces, icon: "🌾", c: "#064e3b" },
          { label: "Total Volume (Kg)", val: totalVolume.toLocaleString("id-ID"), icon: "⚖️", c: "#047857" },
          { label: "Siap Ekspor EUDR", val: eudrReady, icon: "🇪🇺", c: "#065f46" },
        ].map((s, i) => (
          <div key={i} style={{ background: s.c, borderRadius: 12, padding: "16px 18px", color: "#fff" }}>
            <div style={{ fontSize: 11, color: "#a7f3d0", fontWeight: 600, marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontSize: 28, fontWeight: 800 }}>{s.val} {s.icon}</div>
          </div>
        ))}
      </div>

      {successMsg && (
        <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "12px 16px", color: "#15803d", fontWeight: 600, marginBottom: 16, fontSize: 14 }}>
          {successMsg}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: "center", padding: 60, color: "#64748b" }}>⏳ Memuat data...</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {lands.map((land: any) => {
            const landTraces = traces[land.id] || [];
            const landDocs = docs[land.id] || [];
            const landCycles = cycles[land.id] || [];
            const polyVerified = land.has_polygon === true || land.has_polygon === 1;

            // Checklist readiness
            const checks = [
              { label: "Polygon Batas Lahan", ok: polyVerified },
              { label: "EUDR Compliant", ok: land.eudr_status === "Compliant" },
              { label: "Dokumen Pendukung", ok: landDocs.length > 0 },
              { label: "Siklus Tanam Tercatat", ok: landCycles.length > 0 },
            ];
            const readyCount = checks.filter(c => c.ok).length;

            return (
              <div key={land.id} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, overflow: "hidden" }}>
                {/* Land Header */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 20px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0", flexWrap: "wrap", gap: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 9, background: "linear-gradient(135deg,#10b981,#047857)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13 }}>
                      {land.land_name?.[0] || "L"}
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 14 }}>{land.land_name}</div>
                      <div style={{ fontSize: 12, color: "#64748b" }}>🌱 {land.commodity_name} · {land.total_area_hectares} Ha</div>
                    </div>
                  </div>

                  {/* Readiness bar */}
                  <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                    {checks.map((ck, i) => (
                      <span key={i} style={{
                        fontSize: 11, fontWeight: 600, padding: "3px 9px", borderRadius: 20,
                        background: ck.ok ? "#dcfce7" : "#fef2f2",
                        color: ck.ok ? "#15803d" : "#dc2626",
                      }}>
                        {ck.ok ? "✅" : "❌"} {ck.label}
                      </span>
                    ))}
                    <span style={{
                      fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20,
                      background: readyCount === 4 ? "#dcfce7" : "#fff7ed",
                      color: readyCount === 4 ? "#15803d" : "#c2410c",
                    }}>
                      {readyCount}/4 Siap
                    </span>
                    <button
                      onClick={() => { setSelectedLand(land); setShowModal(true); }}
                      style={{ padding: "7px 14px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 12, cursor: "pointer", fontWeight: 600 }}
                    >
                      ➕ Rekam Panen
                    </button>
                  </div>
                </div>

                {/* Traces Table */}
                {landTraces.length === 0 ? (
                  <div style={{ padding: 20, textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                    Belum ada rekaman panen. Klik "Rekam Panen" untuk menambahkan.
                  </div>
                ) : (
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                    <thead>
                      <tr style={{ background: "#f1f5f9" }}>
                        {["Tanggal Panen", "Komoditas", "Volume (Kg)", "Tujuan", "Polygon", "EUDR", "Dokumen", "Aksi"].map(h => (
                          <th key={h} style={{ padding: "9px 12px", textAlign: "left", fontSize: 11, color: "#64748b", fontWeight: 700, textTransform: "uppercase", whiteSpace: "nowrap" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {landTraces.map((tr: any) => (
                        <tr key={tr.id} style={{ borderTop: "1px solid #f1f5f9" }}>
                          <td style={{ padding: "10px 12px", fontWeight: 600 }}>{tr.harvest_date}</td>
                          <td style={{ padding: "10px 12px", color: "#064e3b", fontWeight: 600 }}>🌱 {tr.commodity}</td>
                          <td style={{ padding: "10px 12px", color: "#047857", fontWeight: 700 }}>{(tr.volume_kg || 0).toLocaleString("id-ID")}</td>
                          <td style={{ padding: "10px 12px", color: "#374151" }}>{tr.destination}</td>
                          <td style={{ padding: "10px 12px" }}>
                            <Badge ok={tr.polygon_verified} yes="✅ Ada" no="❌ Belum" />
                          </td>
                          <td style={{ padding: "10px 12px" }}>
                            <Badge ok={tr.eudr_compliant} yes="🛡️ OK" no="⚠️ Tidak" />
                          </td>
                          <td style={{ padding: "10px 12px" }}>
                            <span style={{ fontSize: 11, fontWeight: 600, color: tr.doc_count > 0 ? "#15803d" : "#dc2626" }}>
                              {tr.doc_count} file
                            </span>
                          </td>
                          <td style={{ padding: "10px 12px" }}>
                            <button onClick={() => setViewDetail(tr)}
                              style={{ padding: "4px 10px", borderRadius: 6, background: "#eff6ff", color: "#2563eb", border: "1px solid #bfdbfe", fontSize: 11, cursor: "pointer", fontWeight: 600 }}>
                              📋 Detail
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Rekam Panen */}
      {showModal && selectedLand && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.6)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}
          onClick={() => setShowModal(false)}>
          <div style={{ background: "#fff", borderRadius: 16, width: "90%", maxWidth: 440, overflow: "hidden" }} onClick={e => e.stopPropagation()}>
            <div style={{ background: "linear-gradient(135deg,#064e3b,#10b981)", padding: "18px 22px" }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>🌾 Rekam Hasil Panen</div>
              <div style={{ fontSize: 12, color: "#a7f3d0", marginTop: 2 }}>{selectedLand.land_name}</div>
            </div>
            <form onSubmit={handleAddTrace} style={{ padding: 22 }}>
              <div style={{ marginBottom: 12 }}>
                <label style={lbl}>Tanggal Panen *</label>
                <input required type="date" value={form.harvest_date} onChange={e => setForm(p => ({ ...p, harvest_date: e.target.value }))} style={inp} />
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={lbl}>Volume Hasil Panen (Kg) *</label>
                <input required type="number" min={1} value={form.volume_kg} onChange={e => setForm(p => ({ ...p, volume_kg: e.target.value }))} style={inp} placeholder="misal: 2500" />
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={lbl}>Tujuan / Pembeli</label>
                <input value={form.destination} onChange={e => setForm(p => ({ ...p, destination: e.target.value }))} style={inp} placeholder="PT Eksportir Maju..." />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={lbl}>Catatan</label>
                <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} style={{ ...inp, resize: "vertical" }} />
              </div>
              {/* Summary readiness */}
              <div style={{ background: "#f8fafc", borderRadius: 8, padding: "10px 12px", marginBottom: 16, fontSize: 12 }}>
                <div style={{ fontWeight: 700, color: "#374151", marginBottom: 6 }}>📊 Status Kelengkapan Dokumen:</div>
                {[
                  { label: "Polygon terverifikasi", ok: selectedLand.has_polygon },
                  { label: "EUDR Compliant", ok: selectedLand.eudr_status === "Compliant" },
                  { label: "Dokumen lahan", ok: (docs[selectedLand.id] || []).length > 0 },
                  { label: "Siklus tanam", ok: (cycles[selectedLand.id] || []).length > 0 },
                ].map((ck, i) => (
                  <div key={i} style={{ color: ck.ok ? "#15803d" : "#dc2626", marginBottom: 2 }}>
                    {ck.ok ? "✅" : "❌"} {ck.label}
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ padding: "9px 18px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", fontSize: 13, cursor: "pointer" }}>Batal</button>
                <button type="submit" style={{ padding: "9px 18px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Simpan</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Detail Trace */}
      {viewDetail && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.7)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}
          onClick={() => setViewDetail(null)}>
          <div style={{ background: "#fff", borderRadius: 16, width: "90%", maxWidth: 480, overflow: "hidden" }} onClick={e => e.stopPropagation()}>
            <div style={{ background: "linear-gradient(135deg,#064e3b,#10b981)", padding: "18px 22px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>📋 Detail Traceability</div>
                <div style={{ fontSize: 12, color: "#a7f3d0", marginTop: 2 }}>ID Rekaman: #{viewDetail.id}</div>
              </div>
              <button onClick={() => setViewDetail(null)} style={{ background: "rgba(255,255,255,0.2)", border: "none", color: "#fff", borderRadius: 8, cursor: "pointer", padding: "6px 12px", fontSize: 13 }}>✕ Tutup</button>
            </div>
            <div style={{ padding: 22 }}>
              {[
                ["Komoditas", viewDetail.commodity],
                ["Tanggal Panen", viewDetail.harvest_date],
                ["Volume", `${(viewDetail.volume_kg || 0).toLocaleString("id-ID")} Kg`],
                ["Tujuan", viewDetail.destination || "—"],
                ["Polygon Terverifikasi", viewDetail.polygon_verified ? "✅ Ya" : "❌ Belum"],
                ["EUDR Compliant", viewDetail.eudr_compliant ? "✅ Compliant" : "⚠️ Non-Compliant"],
                ["Jumlah Dokumen", `${viewDetail.doc_count} dokumen`],
                ["Catatan", viewDetail.notes || "—"],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #f1f5f9", fontSize: 13 }}>
                  <span style={{ color: "#64748b", fontWeight: 500 }}>{k}</span>
                  <span style={{ fontWeight: 600, color: "#0f172a" }}>{v}</span>
                </div>
              ))}
              <div style={{ marginTop: 16, padding: "12px", background: viewDetail.eudr_compliant && viewDetail.polygon_verified && viewDetail.doc_count > 0 ? "#f0fdf4" : "#fff7ed", borderRadius: 10, textAlign: "center", fontWeight: 700, fontSize: 14, color: viewDetail.eudr_compliant && viewDetail.polygon_verified ? "#15803d" : "#c2410c" }}>
                {viewDetail.eudr_compliant && viewDetail.polygon_verified && viewDetail.doc_count > 0
                  ? "🇪🇺 Produk ini memenuhi syarat ekspor ke pasar Eropa"
                  : "⚠️ Lengkapi data sebelum ekspor ke Eropa"}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Badge({ ok, yes, no }: { ok: boolean; yes: string; no: string }) {
  return (
    <span style={{
      fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 20,
      background: ok ? "#dcfce7" : "#fef2f2",
      color: ok ? "#15803d" : "#dc2626",
    }}>{ok ? yes : no}</span>
  );
}

const lbl: React.CSSProperties = { display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6 };
const inp: React.CSSProperties = { width: "100%", padding: "9px 12px", border: "1px solid #d1d5db", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" };
