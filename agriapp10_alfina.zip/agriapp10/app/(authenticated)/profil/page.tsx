"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { MOCK_USER_PROFILE } from "@/lib/mockData";

export default function ProfilPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [farmer, setFarmer] = useState<any>(null);
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [token, setToken] = useState("");

  useEffect(() => {
    const u = localStorage.getItem("user");
    const f = localStorage.getItem("farmer");
    const t = localStorage.getItem("access_token") || "";
    setToken(t);
    if (u) {
      const parsed = JSON.parse(u);
      setUser(parsed);
      setForm({
        full_name: parsed.full_name || "",
        email: parsed.email || "",
        phone: parsed.phone || "",
        address: parsed.address || "",
        nik: parsed.nik || "",
      });
    } else {
      // Fallback mock
      setUser(MOCK_USER_PROFILE);
      setForm({ full_name: MOCK_USER_PROFILE.full_name, email: MOCK_USER_PROFILE.email, phone: MOCK_USER_PROFILE.phone, address: MOCK_USER_PROFILE.address, nik: MOCK_USER_PROFILE.nik });
    }
    if (f) setFarmer(JSON.parse(f));
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");
    try {
      const fd = new URLSearchParams();
      Object.entries(form).forEach(([k, v]) => fd.append(k, String(v)));
      const res = await fetch("/api/proxy/profile/update", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: fd.toString(),
      });
      if (res.ok) {
        const updatedUser = { ...user, ...form };
        localStorage.setItem("user", JSON.stringify(updatedUser));
        setUser(updatedUser);
      }
      // Apapun responsnya, simpan lokal
      const updatedUser = { ...user, ...form };
      localStorage.setItem("user", JSON.stringify(updatedUser));
      setUser(updatedUser);
      setEditMode(false);
      setSuccessMsg("✅ Profil berhasil diperbarui");
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch {
      const updatedUser = { ...user, ...form };
      localStorage.setItem("user", JSON.stringify(updatedUser));
      setUser(updatedUser);
      setEditMode(false);
      setSuccessMsg("✅ Profil diperbarui (offline)");
      setTimeout(() => setSuccessMsg(""), 3000);
    } finally {
      setLoading(false);
    }
  }

  if (!user) return <div style={{ padding: 40, textAlign: "center" }}>⏳ Memuat profil...</div>;

  const initials = (user.full_name || "U").split(" ").map((n: string) => n[0]).join("").substring(0, 2).toUpperCase();

  return (
    <div style={{ padding: 24, maxWidth: 720, margin: "0 auto", fontFamily: "Inter, sans-serif" }}>
      {/* Header Card */}
      <div style={{ background: "linear-gradient(135deg,#064e3b,#047857)", borderRadius: 16, padding: "28px 32px", marginBottom: 24, display: "flex", alignItems: "center", gap: 20 }}>
        <div style={{ width: 72, height: 72, borderRadius: "50%", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 800, color: "#fff", flexShrink: 0, border: "3px solid rgba(255,255,255,0.3)" }}>
          {initials}
        </div>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#fff" }}>{user.full_name || "Petani"}</h2>
          <div style={{ fontSize: 13, color: "#a7f3d0", marginTop: 4 }}>@{user.username || "—"}</div>
          <span style={{ display: "inline-block", marginTop: 6, fontSize: 11, fontWeight: 700, padding: "3px 12px", borderRadius: 20, background: "rgba(255,255,255,0.15)", color: "#fff" }}>
            🌱 Farmer
          </span>
        </div>
      </div>

      {successMsg && (
        <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "12px 16px", color: "#15803d", fontWeight: 600, marginBottom: 16, fontSize: 14 }}>
          {successMsg}
        </div>
      )}

      {/* Profile Data */}
      <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, overflow: "hidden", marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 22px", borderBottom: "1px solid #f1f5f9" }}>
          <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 15 }}>👤 Data Profil</div>
          {!editMode && (
            <button onClick={() => setEditMode(true)}
              style={{ padding: "7px 16px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 13, cursor: "pointer", fontWeight: 600 }}>
              ✏️ Ubah Data
            </button>
          )}
        </div>

        {!editMode ? (
          <div style={{ padding: "4px 0" }}>
            {[
              ["Nama Lengkap", user.full_name, "👤"],
              ["Username", user.username, "🔤"],
              ["Email", user.email, "✉️"],
              ["NIK", user.nik || "—", "🪪"],
              ["No HP", user.phone || "—", "📱"],
              ["Alamat", user.address || "—", "📍"],
            ].map(([label, value, icon]) => (
              <div key={String(label)} style={{ display: "flex", padding: "13px 22px", borderBottom: "1px solid #f8fafc" }}>
                <div style={{ width: 160, fontSize: 13, color: "#64748b", fontWeight: 500, flexShrink: 0 }}>{icon} {label}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#0f172a" }}>{String(value)}</div>
              </div>
            ))}
          </div>
        ) : (
          <form onSubmit={handleSave} style={{ padding: 22 }}>
            {errorMsg && (
              <div style={{ background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: 8, padding: "10px 14px", color: "#b91c1c", fontSize: 13, marginBottom: 16 }}>{errorMsg}</div>
            )}
            {[
              { name: "full_name", label: "Nama Lengkap", type: "text", required: true },
              { name: "email", label: "Email", type: "email", required: true },
              { name: "nik", label: "NIK", type: "text" },
              { name: "phone", label: "No HP", type: "text" },
            ].map(f => (
              <div key={f.name} style={{ marginBottom: 14 }}>
                <label style={lbl}>{f.label} {f.required && "*"}</label>
                <input
                  required={f.required}
                  type={f.type}
                  value={form[f.name] || ""}
                  onChange={e => setForm((p: any) => ({ ...p, [f.name]: e.target.value }))}
                  style={inp}
                />
              </div>
            ))}
            <div style={{ marginBottom: 14 }}>
              <label style={lbl}>Alamat</label>
              <textarea value={form.address || ""} onChange={e => setForm((p: any) => ({ ...p, address: e.target.value }))} rows={3} style={{ ...inp, resize: "vertical" }} />
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 6 }}>
              <button type="button" onClick={() => setEditMode(false)}
                style={{ padding: "9px 18px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", fontSize: 13, cursor: "pointer" }}>
                Batal
              </button>
              <button type="submit" disabled={loading}
                style={{ padding: "9px 18px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: loading ? 0.7 : 1 }}>
                {loading ? "Menyimpan..." : "Simpan Perubahan"}
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Shortcut */}
      <div style={{ display: "flex", gap: 12 }}>
        <button onClick={() => router.push("/change-password")}
          style={{ flex: 1, padding: "12px", borderRadius: 10, background: "#fff", border: "1px solid #e2e8f0", fontSize: 13, cursor: "pointer", fontWeight: 600, color: "#374151" }}>
          🔑 Ubah Password
        </button>
        <button onClick={() => { localStorage.clear(); router.push("/login"); }}
          style={{ padding: "12px 20px", borderRadius: 10, background: "#fef2f2", border: "1px solid #fecaca", fontSize: 13, cursor: "pointer", fontWeight: 600, color: "#dc2626" }}>
          🚪 Logout
        </button>
      </div>
    </div>
  );
}

const lbl: React.CSSProperties = { display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6 };
const inp: React.CSSProperties = { width: "100%", padding: "9px 12px", border: "1px solid #d1d5db", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" };
