"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { MOCK_LANDS, MOCK_DOCUMENTS } from "@/lib/mockData";

const DOC_TYPES = ["Sertifikat", "Izin", "SK", "Peta", "Kontrak", "Lainnya"];

export default function LandDocumentsPage() {
  const router = useRouter();
  const [token, setToken] = useState("");
  const [lands, setLands] = useState<any[]>([]);
  const [docs, setDocs] = useState<Record<number, any[]>>({});
  const [selectedLand, setSelectedLand] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ doc_name: "", doc_type: "Sertifikat", notes: "" });
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    const t = localStorage.getItem("access_token") || "";
    setToken(t);
    loadData(t);
  }, []);

  async function loadData(t: string) {
    setLoading(true);
    try {
      const res = await fetch("/api/proxy/land", {
        headers: { Authorization: `Bearer ${t}`, Accept: "application/json" },
      });
      if (res.ok) {
        const json = await res.json();
        const items = Array.isArray(json) ? json : json.data || [];
        setLands(items.length ? items : MOCK_LANDS);
      } else {
        setLands(MOCK_LANDS);
      }
    } catch {
      setLands(MOCK_LANDS);
    }

    // Load dokumen dari API atau mock
    try {
      const res2 = await fetch("/api/proxy/land-documents", {
        headers: { Authorization: `Bearer ${t}`, Accept: "application/json" },
      });
      if (res2.ok) {
        const json2 = await res2.json();
        setDocs(json2.data || MOCK_DOCUMENTS);
      } else {
        setDocs(MOCK_DOCUMENTS);
      }
    } catch {
      setDocs(MOCK_DOCUMENTS);
    }
    setLoading(false);
  }

  async function handleAddDoc(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedLand) return;

    const newDoc = {
      id: Date.now(),
      land_id: selectedLand.id,
      doc_name: form.doc_name,
      doc_type: form.doc_type,
      file_url: "#",
      uploaded_at: new Date().toISOString().split("T")[0],
      status: "Pending",
      notes: form.notes,
    };

    // Coba POST ke API, kalau gagal simpan lokal
    try {
      const fd = new URLSearchParams();
      fd.append("land_id", String(selectedLand.id));
      fd.append("doc_name", form.doc_name);
      fd.append("doc_type", form.doc_type);
      await fetch("/api/proxy/land-documents/create", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: fd.toString(),
      });
    } catch {}

    setDocs((prev) => ({
      ...prev,
      [selectedLand.id]: [...(prev[selectedLand.id] || []), newDoc],
    }));
    setShowModal(false);
    setForm({ doc_name: "", doc_type: "Sertifikat", notes: "" });
    setSuccessMsg("✅ Dokumen berhasil ditambahkan");
    setTimeout(() => setSuccessMsg(""), 3000);
  }

  const totalDocs = Object.values(docs).flat().length;
  const verifiedDocs = Object.values(docs).flat().filter((d: any) => d.status === "Verified").length;

  return (
    <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#064e3b,#047857,#10b981)", borderRadius: 16, padding: "28px 32px", marginBottom: 24, color: "#fff" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>📁</div>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>Land Documents</h2>
            <p style={{ margin: 0, fontSize: 13, color: "#a7f3d0" }}>Dokumen pendukung lahan untuk kepatuhan ekspor Eropa (EUDR)</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Lahan", val: lands.length, icon: "⛰️", color: "#064e3b" },
          { label: "Total Dokumen", val: totalDocs, icon: "📄", color: "#047857" },
          { label: "Dokumen Verified", val: verifiedDocs, icon: "✅", color: "#065f46" },
        ].map((s, i) => (
          <div key={i} style={{ background: s.color, borderRadius: 12, padding: "18px 20px", color: "#fff" }}>
            <div style={{ fontSize: 11, color: "#a7f3d0", fontWeight: 600, marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontSize: 32, fontWeight: 800, display: "flex", alignItems: "center", gap: 8 }}>
              {s.val} <span style={{ fontSize: 22 }}>{s.icon}</span>
            </div>
          </div>
        ))}
      </div>

      {successMsg && (
        <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "12px 16px", color: "#15803d", fontWeight: 600, marginBottom: 16, fontSize: 14 }}>
          {successMsg}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: "center", padding: 60, color: "#64748b" }}>⏳ Memuat data...</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {lands.map((land: any) => {
            const landDocs = docs[land.id] || [];
            return (
              <div key={land.id} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, overflow: "hidden", boxShadow: "0 1px 6px rgba(0,0,0,0.05)" }}>
                {/* Land header */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 20px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 9, background: "linear-gradient(135deg,#10b981,#047857)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13 }}>
                      {land.land_name?.[0] || "L"}
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 14 }}>{land.land_name}</div>
                      <div style={{ fontSize: 12, color: "#64748b" }}>🌱 {land.commodity_name} · {land.total_area_hectares} Ha</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{
                      fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20,
                      background: landDocs.length > 0 ? "#dcfce7" : "#fef2f2",
                      color: landDocs.length > 0 ? "#15803d" : "#dc2626",
                    }}>
                      {landDocs.length} Dokumen
                    </span>
                    <button
                      onClick={() => { setSelectedLand(land); setShowModal(true); }}
                      style={{ display: "flex", alignItems: "center", gap: 5, padding: "7px 14px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 12, cursor: "pointer", fontWeight: 600 }}
                    >
                      ➕ Tambah Dokumen
                    </button>
                  </div>
                </div>

                {/* Dokumen list */}
                {landDocs.length === 0 ? (
                  <div style={{ padding: "20px", textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                    Belum ada dokumen. Tambahkan dokumen pendukung untuk lahan ini.
                  </div>
                ) : (
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                    <thead>
                      <tr style={{ background: "#f1f5f9" }}>
                        {["Nama Dokumen", "Tipe", "Tanggal Upload", "Status", "Aksi"].map(h => (
                          <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {landDocs.map((doc: any) => (
                        <tr key={doc.id} style={{ borderTop: "1px solid #f1f5f9" }}>
                          <td style={{ padding: "10px 14px", fontWeight: 600, color: "#0f172a" }}>📄 {doc.doc_name}</td>
                          <td style={{ padding: "10px 14px", color: "#64748b" }}>{doc.doc_type}</td>
                          <td style={{ padding: "10px 14px", color: "#64748b" }}>{doc.uploaded_at}</td>
                          <td style={{ padding: "10px 14px" }}>
                            <span style={{
                              fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20,
                              background: doc.status === "Verified" ? "#dcfce7" : "#fef9c3",
                              color: doc.status === "Verified" ? "#15803d" : "#a16207",
                            }}>
                              {doc.status === "Verified" ? "✅ Verified" : "⏳ Pending"}
                            </span>
                          </td>
                          <td style={{ padding: "10px 14px" }}>
                            <a href={doc.file_url} style={{ fontSize: 12, color: "#2563eb", textDecoration: "none", fontWeight: 600 }}>🔗 Lihat</a>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Tambah Dokumen */}
      {showModal && selectedLand && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.6)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}
          onClick={() => setShowModal(false)}>
          <div style={{ background: "#fff", borderRadius: 16, width: "90%", maxWidth: 440, overflow: "hidden", boxShadow: "0 24px 60px rgba(0,0,0,0.25)" }}
            onClick={e => e.stopPropagation()}>
            <div style={{ background: "linear-gradient(135deg,#064e3b,#10b981)", padding: "18px 22px" }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>📁 Tambah Dokumen Lahan</div>
              <div style={{ fontSize: 12, color: "#a7f3d0", marginTop: 2 }}>{selectedLand.land_name}</div>
            </div>
            <form onSubmit={handleAddDoc} style={{ padding: 22 }}>
              <div style={{ marginBottom: 14 }}>
                <label style={lbl}>Nama Dokumen *</label>
                <input required value={form.doc_name} onChange={e => setForm(p => ({ ...p, doc_name: e.target.value }))}
                  placeholder="Sertifikat Tanah HM No. 123..." style={inp} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={lbl}>Tipe Dokumen *</label>
                <select value={form.doc_type} onChange={e => setForm(p => ({ ...p, doc_type: e.target.value }))} style={inp}>
                  {DOC_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ marginBottom: 18 }}>
                <label style={lbl}>Catatan</label>
                <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
                  rows={2} style={{ ...inp, resize: "vertical" }} placeholder="Keterangan tambahan..." />
              </div>
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
                <button type="button" onClick={() => setShowModal(false)}
                  style={{ padding: "9px 18px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", fontSize: 13, cursor: "pointer" }}>
                  Batal
                </button>
                <button type="submit"
                  style={{ padding: "9px 18px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
                  Simpan Dokumen
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const lbl: React.CSSProperties = { display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6 };
const inp: React.CSSProperties = { width: "100%", padding: "9px 12px", border: "1px solid #d1d5db", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" };
