"use client";

import { useEffect, useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { MOCK_LANDS, MOCK_DOCUMENTS, MOCK_PLANTING_CYCLES } from "@/lib/mockData";

export default function DashboardPage() {
  const router = useRouter();
  const [lands, setLands] = useState<any[]>([]);
  const [docs, setDocs] = useState<Record<number, any[]>>({});
  const [cycles, setCycles] = useState<Record<number, any[]>>({});
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    document.title = `Dashboard | ${process.env.NEXT_PUBLIC_APP_NAME}`;
    const token = localStorage.getItem("access_token");
    const u = localStorage.getItem("user");
    if (u) setUser(JSON.parse(u));
    if (!token) { router.push("/login"); return; }
    fetchAll(token);
  }, []);

  async function fetchAll(token: string) {
    setLoading(true);
    // Lands
    try {
      const res = await fetch("/api/proxy/land", { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const json = await res.json();
        setLands(Array.isArray(json) ? json : json.data || MOCK_LANDS);
      } else setLands(MOCK_LANDS);
    } catch { setLands(MOCK_LANDS); }

    // Docs (mock)
    try {
      const res2 = await fetch("/api/proxy/land-documents", { headers: { Authorization: `Bearer ${token}` } });
      if (res2.ok) { const j2 = await res2.json(); setDocs(j2.data || MOCK_DOCUMENTS); }
      else setDocs(MOCK_DOCUMENTS);
    } catch { setDocs(MOCK_DOCUMENTS); }

    // Cycles (mock)
    try {
      const res3 = await fetch("/api/proxy/planting-cycles", { headers: { Authorization: `Bearer ${token}` } });
      if (res3.ok) { const j3 = await res3.json(); setCycles(j3.data || MOCK_PLANTING_CYCLES); }
      else setCycles(MOCK_PLANTING_CYCLES);
    } catch { setCycles(MOCK_PLANTING_CYCLES); }
    setLoading(false);
  }

  const metrics = useMemo(() => {
    const totalParcels = lands.length;
    const totalArea = lands.reduce((s, l) => s + (Number(l.total_area_hectares) || 0), 0);
    const activeCycles = Object.values(cycles).flat().filter((c: any) => !c.harvest_date).length;
    const compliantLands = lands.filter(l => l.eudr_status === "Compliant").length;
    const complianceRate = totalParcels ? Math.round((compliantLands / totalParcels) * 100) : 0;
    const mappedLands = lands.filter(l => l.has_polygon === true || l.has_polygon === 1).length;
    const totalDocs = Object.values(docs).flat().length;
    const uniqueCommodities = [...new Set(lands.map(l => l.commodity_name).filter(Boolean))];
    return { totalParcels, totalArea: totalArea.toFixed(1), activeCycles, complianceRate, mappedLands, totalDocs, uniqueCommodities };
  }, [lands, cycles, docs]);

  // Compliance checklist
  const checklists = [
    { label: "Petakan Batas Lahan", desc: "Pastikan semua lahan sudah dipetakan dengan polygon koordinat satelit.", done: metrics.mappedLands === metrics.totalParcels && metrics.totalParcels > 0, path: "/land-polygon" },
    { label: "Upload Dokumen Deforestasi", desc: "Hubungkan dokumen legalitas lahan untuk jaminan kepatuhan EUDR.", done: metrics.totalDocs > 0, path: "/documents" },
    { label: "Perbarui Data Siklus Tanam", desc: "Log aktivitas tanam aktif agar data panen tidak terblokir.", done: metrics.activeCycles > 0, path: "/planting-cycles" },
  ];

  const name = user?.full_name || "Farmer";

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", flexDirection: "column", gap: 16 }}>
        <div style={{ width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg,#047857,#34d399)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg style={{ animation: "spin .8s linear infinite" }} viewBox="0 0 24 24" fill="none" width="26" height="26">
            <circle cx="12" cy="12" r="10" stroke="rgba(255,255,255,0.3)" strokeWidth="3"/>
            <path d="M12 2a10 10 0 0 1 10 10" stroke="#fff" strokeWidth="3" strokeLinecap="round"/>
          </svg>
        </div>
        <div style={{ color: "#374151", fontWeight: 600, fontSize: 14 }}>Memuat dashboard...</div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24, fontFamily: "Inter, sans-serif" }}>
      {/* Welcome */}
      <div>
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: "#0f172a" }}>Welcome Back, {name.split(" ")[0]}! 👋</h2>
        <p style={{ margin: "4px 0 0", fontSize: 13, color: "#64748b" }}>Status operasional real-time & kesehatan kepatuhan EUDR aset perkebunan Anda.</p>
      </div>

      {/* Metric Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 16 }}>
        {[
          { label: "Total Lahan Terdaftar", val: `${metrics.totalParcels}`, sub: "Parcel", icon: "⛰️", note: `${metrics.mappedLands} terpetakan`, noteOk: metrics.mappedLands === metrics.totalParcels },
          { label: "Total Luasan", val: `${metrics.totalArea}`, sub: "Hektar", icon: "📐", note: "Batas polygon terverifikasi", noteOk: metrics.mappedLands > 0 },
          { label: "Siklus Tanam Aktif", val: `${metrics.activeCycles}`, sub: "Siklus", icon: "🔄", note: "Logging aktivitas aktif", noteOk: metrics.activeCycles > 0 },
          { label: "EUDR Compliance Rate", val: `${metrics.complianceRate}%`, sub: "", icon: "🛡️", note: "Target: 100% Zero-Deforestasi", noteOk: metrics.complianceRate === 100 },
        ].map((s, i) => (
          <div key={i} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: 20, boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
              <span style={{ fontSize: 12, color: "#64748b", fontWeight: 600 }}>{s.label}</span>
              <span style={{ fontSize: 22 }}>{s.icon}</span>
            </div>
            <div style={{ fontSize: 30, fontWeight: 800, color: "#0f172a" }}>{s.val} <span style={{ fontSize: 14, fontWeight: 400, color: "#64748b" }}>{s.sub}</span></div>
            <div style={{ fontSize: 11, marginTop: 6, color: s.noteOk ? "#22c55e" : "#f59e0b", fontWeight: 500 }}>
              {s.noteOk ? "✅" : "⚠️"} {s.note}
            </div>
          </div>
        ))}
      </div>

      {/* Body: Checklist + Info */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 20, alignItems: "start", flexWrap: "wrap" }}>
        {/* Compliance Checklist */}
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: "#0f172a" }}>📋 Required Compliance Checklists</div>
            <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>Selesaikan langkah ini untuk membuka akses ekspor internasional.</div>
          </div>
          {checklists.map((ck, i) => (
            <div key={i}
              onClick={() => router.push(ck.path)}
              style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", borderBottom: i < checklists.length - 1 ? "1px solid #f1f5f9" : "none", cursor: "pointer", transition: "background 0.15s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "#f8fafc")}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              <div style={{ width: 40, height: 40, borderRadius: 10, background: ck.done ? "#dcfce7" : "#fef9c3", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
                {ck.done ? "✅" : "⏳"}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>{ck.label}</div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{ck.desc}</div>
              </div>
              <span style={{ color: "#94a3b8", fontSize: 18 }}>›</span>
            </div>
          ))}
        </div>

        {/* EUDR Info Card */}
        <div style={{ background: "#0f172a", borderRadius: 14, padding: 20, width: 240, flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 6, background: "#1e40af", color: "#93c5fd" }}>🇪🇺 EUDR MARKET GATE</span>
          </div>
          <div style={{ fontWeight: 800, color: "#fff", fontSize: 15, marginBottom: 8 }}>Zero Deforestation Policy</div>
          <div style={{ fontSize: 12, color: "#94a3b8", lineHeight: 1.6, marginBottom: 12 }}>
            Rantai pasokan Anda harus membuktikan tidak ada deforestasi yang terjadi setelah tanggal 31 Desember 2020. Perbarui data polygon Anda secara berkala.
          </div>
          <div style={{ fontSize: 10, color: "#475569" }}>Disinkronkan dengan standar RSPO & ISPO.</div>
          <div style={{ marginTop: 14, padding: "10px", borderRadius: 8, background: metrics.complianceRate === 100 ? "#14532d" : "#450a0a", textAlign: "center" }}>
            <div style={{ fontSize: 24, fontWeight: 800, color: metrics.complianceRate === 100 ? "#4ade80" : "#f87171" }}>{metrics.complianceRate}%</div>
            <div style={{ fontSize: 10, color: "#94a3b8" }}>Compliance Rate</div>
          </div>
        </div>
      </div>

      {/* Summary commodities */}
      {metrics.uniqueCommodities.length > 0 && (
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "16px 20px" }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#0f172a", marginBottom: 12 }}>🌱 Komoditas Terdaftar</div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {metrics.uniqueCommodities.map(c => (
              <span key={c} style={{ padding: "6px 14px", borderRadius: 20, background: "#f0fdf4", color: "#065f46", fontSize: 13, fontWeight: 600, border: "1px solid #a7f3d0" }}>
                🌿 {c}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
