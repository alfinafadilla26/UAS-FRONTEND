"use client";

import { useEffect, useState } from "react";
import { MOCK_LANDS, MOCK_PLANTING_CYCLES } from "@/lib/mockData";

const PHASES = ["Bibit", "Perawatan", "Pengairan", "Pemupukan", "Penanganan Hama", "Panen"];
const ACTIVITY_TYPES = ["Pengairan", "Pemupukan", "Penanganan Hama", "Pemangkasan", "Panen", "Lainnya"];

export default function PlantingCyclesPage() {
  const [token, setToken] = useState("");
  const [lands, setLands] = useState<any[]>([]);
  const [cycles, setCycles] = useState<Record<number, any[]>>({});
  const [expandedLand, setExpandedLand] = useState<number | null>(null);
  const [expandedCycle, setExpandedCycle] = useState<number | null>(null);
  const [showCycleModal, setShowCycleModal] = useState(false);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [selectedLand, setSelectedLand] = useState<any>(null);
  const [selectedCycle, setSelectedCycle] = useState<any>(null);
  const [cycleForm, setCycleForm] = useState({ planting_date: "", harvest_date: "", phase: "Bibit", notes: "" });
  const [actForm, setActForm] = useState({ type: "Pengairan", date: "", cost: "", note: "" });
  const [successMsg, setSuccessMsg] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = localStorage.getItem("access_token") || "";
    setToken(t);
    loadData(t);
  }, []);

  async function loadData(t: string) {
    setLoading(true);
    try {
      const res = await fetch("/api/proxy/land", { headers: { Authorization: `Bearer ${t}`, Accept: "application/json" } });
      if (res.ok) {
        const json = await res.json();
        const items = Array.isArray(json) ? json : json.data || [];
        setLands(items.length ? items : MOCK_LANDS);
      } else setLands(MOCK_LANDS);
    } catch { setLands(MOCK_LANDS); }

    try {
      const res2 = await fetch("/api/proxy/planting-cycles", { headers: { Authorization: `Bearer ${t}`, Accept: "application/json" } });
      if (res2.ok) {
        const json2 = await res2.json();
        setCycles(json2.data || MOCK_PLANTING_CYCLES);
      } else setCycles(MOCK_PLANTING_CYCLES);
    } catch { setCycles(MOCK_PLANTING_CYCLES); }
    setLoading(false);
  }

  function toast(msg: string) {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 3000);
  }

  async function handleAddCycle(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedLand) return;
    const newCycle = {
      id: Date.now(),
      land_id: selectedLand.id,
      commodity: selectedLand.commodity_name || "—",
      phase: cycleForm.phase,
      planting_date: cycleForm.planting_date,
      harvest_date: cycleForm.harvest_date || null,
      notes: cycleForm.notes,
      activities: [],
    };
    setCycles(prev => ({ ...prev, [selectedLand.id]: [...(prev[selectedLand.id] || []), newCycle] }));
    setShowCycleModal(false);
    setCycleForm({ planting_date: "", harvest_date: "", phase: "Bibit", notes: "" });
    toast("✅ Siklus tanaman berhasil ditambahkan");
  }

  async function handleAddActivity(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedCycle || !selectedLand) return;
    const newAct = {
      id: Date.now(),
      cycle_id: selectedCycle.id,
      type: actForm.type,
      date: actForm.date,
      cost: Number(actForm.cost) || 0,
      note: actForm.note,
    };
    setCycles(prev => {
      const landCycles = (prev[selectedLand.id] || []).map(c =>
        c.id === selectedCycle.id ? { ...c, activities: [...(c.activities || []), newAct] } : c
      );
      return { ...prev, [selectedLand.id]: landCycles };
    });
    setShowActivityModal(false);
    setActForm({ type: "Pengairan", date: "", cost: "", note: "" });
    toast("✅ Aktivitas berhasil ditambahkan");
  }

  const phaseColor: Record<string, { bg: string; color: string }> = {
    Bibit:    { bg: "#ecfdf5", color: "#059669" },
    Perawatan:{ bg: "#eff6ff", color: "#2563eb" },
    Panen:    { bg: "#f0fdf4", color: "#15803d" },
    default:  { bg: "#f8fafc", color: "#64748b" },
  };

  const totalCycles = Object.values(cycles).flat().length;
  const activeCycles = Object.values(cycles).flat().filter((c: any) => !c.harvest_date).length;

  return (
    <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#064e3b,#047857,#10b981)", borderRadius: 16, padding: "28px 32px", marginBottom: 24, color: "#fff" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🔄</div>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800 }}>Siklus Tanaman</h2>
            <p style={{ margin: 0, fontSize: 13, color: "#a7f3d0" }}>Manajemen siklus tanam: bibit, perawatan hingga panen</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Lahan", val: lands.length, icon: "⛰️", c: "#064e3b" },
          { label: "Total Siklus", val: totalCycles, icon: "🔄", c: "#047857" },
          { label: "Siklus Aktif", val: activeCycles, icon: "🌱", c: "#065f46" },
          { label: "Sudah Panen", val: totalCycles - activeCycles, icon: "🌾", c: "#0f172a" },
        ].map((s, i) => (
          <div key={i} style={{ background: s.c, borderRadius: 12, padding: "16px 18px", color: "#fff" }}>
            <div style={{ fontSize: 11, color: "#a7f3d0", fontWeight: 600, marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontSize: 28, fontWeight: 800 }}>{s.val} {s.icon}</div>
          </div>
        ))}
      </div>

      {successMsg && (
        <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: "12px 16px", color: "#15803d", fontWeight: 600, marginBottom: 16, fontSize: 14 }}>
          {successMsg}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: "center", padding: 60, color: "#64748b" }}>⏳ Memuat data...</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {lands.map((land: any) => {
            const landCycles = cycles[land.id] || [];
            const isExpanded = expandedLand === land.id;
            return (
              <div key={land.id} style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, overflow: "hidden" }}>
                {/* Land Header */}
                <div
                  style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 20px", background: "#f8fafc", borderBottom: isExpanded ? "1px solid #e2e8f0" : "none", cursor: "pointer" }}
                  onClick={() => setExpandedLand(isExpanded ? null : land.id)}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 9, background: "linear-gradient(135deg,#10b981,#047857)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13 }}>
                      {land.land_name?.[0] || "L"}
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 14 }}>{land.land_name}</div>
                      <div style={{ fontSize: 12, color: "#64748b" }}>🌱 {land.commodity_name} · {land.total_area_hectares} Ha · {landCycles.length} siklus</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <button
                      onClick={ev => { ev.stopPropagation(); setSelectedLand(land); setShowCycleModal(true); }}
                      style={{ display: "flex", alignItems: "center", gap: 5, padding: "7px 14px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 12, cursor: "pointer", fontWeight: 600 }}
                    >
                      ➕ Tambah Siklus
                    </button>
                    <span style={{ fontSize: 18 }}>{isExpanded ? "▾" : "▸"}</span>
                  </div>
                </div>

                {/* Cycles */}
                {isExpanded && (
                  <div style={{ padding: "16px 20px" }}>
                    {landCycles.length === 0 ? (
                      <div style={{ textAlign: "center", padding: "20px", color: "#94a3b8", fontSize: 13 }}>
                        Belum ada siklus tanaman. Klik "Tambah Siklus" untuk memulai.
                      </div>
                    ) : (
                      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                        {landCycles.map((cycle: any) => {
                          const pc = phaseColor[cycle.phase] || phaseColor.default;
                          const isCycleExpanded = expandedCycle === cycle.id;
                          const totalCost = (cycle.activities || []).reduce((s: number, a: any) => s + (a.cost || 0), 0);
                          return (
                            <div key={cycle.id} style={{ border: "1px solid #e2e8f0", borderRadius: 10, overflow: "hidden" }}>
                              <div
                                style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", background: "#fafbfc", cursor: "pointer" }}
                                onClick={() => setExpandedCycle(isCycleExpanded ? null : cycle.id)}
                              >
                                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                  <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20, background: pc.bg, color: pc.color }}>{cycle.phase}</span>
                                  <div>
                                    <div style={{ fontWeight: 600, fontSize: 13, color: "#0f172a" }}>{cycle.commodity} — Mulai: {cycle.planting_date}</div>
                                    <div style={{ fontSize: 11, color: "#64748b" }}>
                                      Panen: {cycle.harvest_date || "Belum dipanen"} · {cycle.activities?.length || 0} aktivitas · Biaya: Rp {totalCost.toLocaleString("id-ID")}
                                    </div>
                                  </div>
                                </div>
                                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                  <button
                                    onClick={ev => { ev.stopPropagation(); setSelectedLand(land); setSelectedCycle(cycle); setShowActivityModal(true); }}
                                    style={{ padding: "5px 12px", borderRadius: 6, background: "#eff6ff", color: "#2563eb", border: "1px solid #bfdbfe", fontSize: 11, cursor: "pointer", fontWeight: 600 }}
                                  >
                                    ➕ Aktivitas
                                  </button>
                                  <span style={{ fontSize: 16 }}>{isCycleExpanded ? "▾" : "▸"}</span>
                                </div>
                              </div>

                              {isCycleExpanded && (
                                <div style={{ padding: "0 16px 16px" }}>
                                  {cycle.notes && (
                                    <div style={{ background: "#f0fdf4", borderRadius: 8, padding: "8px 12px", fontSize: 13, color: "#374151", marginTop: 10, marginBottom: 12 }}>
                                      📝 {cycle.notes}
                                    </div>
                                  )}
                                  {!cycle.activities?.length ? (
                                    <div style={{ textAlign: "center", padding: 16, color: "#94a3b8", fontSize: 13 }}>Belum ada aktivitas tercatat</div>
                                  ) : (
                                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                                      <thead>
                                        <tr style={{ background: "#f1f5f9" }}>
                                          {["Jenis Aktivitas", "Tanggal", "Biaya (Rp)", "Keterangan"].map(h => (
                                            <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontSize: 11, fontWeight: 700, textTransform: "uppercase" }}>{h}</th>
                                          ))}
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {cycle.activities.map((act: any) => (
                                          <tr key={act.id} style={{ borderTop: "1px solid #f1f5f9" }}>
                                            <td style={{ padding: "8px 12px", fontWeight: 600 }}>🌿 {act.type}</td>
                                            <td style={{ padding: "8px 12px", color: "#64748b" }}>{act.date}</td>
                                            <td style={{ padding: "8px 12px", color: "#047857", fontWeight: 600 }}>{(act.cost || 0).toLocaleString("id-ID")}</td>
                                            <td style={{ padding: "8px 12px", color: "#64748b" }}>{act.note || "—"}</td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Tambah Siklus */}
      {showCycleModal && (
        <Modal title="🔄 Tambah Siklus Tanaman" subtitle={selectedLand?.land_name} onClose={() => setShowCycleModal(false)}>
          <form onSubmit={handleAddCycle}>
            <Field label="Fase Tanam *">
              <select required value={cycleForm.phase} onChange={e => setCycleForm(p => ({ ...p, phase: e.target.value }))} style={inp}>
                {PHASES.map(p => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Tanggal Mulai Tanam *">
              <input required type="date" value={cycleForm.planting_date} onChange={e => setCycleForm(p => ({ ...p, planting_date: e.target.value }))} style={inp} />
            </Field>
            <Field label="Estimasi / Tanggal Panen">
              <input type="date" value={cycleForm.harvest_date} onChange={e => setCycleForm(p => ({ ...p, harvest_date: e.target.value }))} style={inp} />
            </Field>
            <Field label="Catatan">
              <textarea value={cycleForm.notes} onChange={e => setCycleForm(p => ({ ...p, notes: e.target.value }))} rows={2} style={{ ...inp, resize: "vertical" }} placeholder="Informasi tambahan..." />
            </Field>
            <ModalActions onCancel={() => setShowCycleModal(false)} submitLabel="Simpan Siklus" />
          </form>
        </Modal>
      )}

      {/* Modal Tambah Aktivitas */}
      {showActivityModal && (
        <Modal title="🌿 Tambah Aktivitas" subtitle={`${selectedLand?.land_name} → ${selectedCycle?.phase}`} onClose={() => setShowActivityModal(false)}>
          <form onSubmit={handleAddActivity}>
            <Field label="Jenis Aktivitas *">
              <select required value={actForm.type} onChange={e => setActForm(p => ({ ...p, type: e.target.value }))} style={inp}>
                {ACTIVITY_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Tanggal *">
              <input required type="date" value={actForm.date} onChange={e => setActForm(p => ({ ...p, date: e.target.value }))} style={inp} />
            </Field>
            <Field label="Biaya (Rp)">
              <input type="number" min={0} value={actForm.cost} onChange={e => setActForm(p => ({ ...p, cost: e.target.value }))} style={inp} placeholder="0" />
            </Field>
            <Field label="Keterangan">
              <textarea value={actForm.note} onChange={e => setActForm(p => ({ ...p, note: e.target.value }))} rows={2} style={{ ...inp, resize: "vertical" }} placeholder="Catatan aktivitas..." />
            </Field>
            <ModalActions onCancel={() => setShowActivityModal(false)} submitLabel="Simpan Aktivitas" />
          </form>
        </Modal>
      )}
    </div>
  );
}

// ── Helper Components ──────────────────────────────────────────────
function Modal({ title, subtitle, onClose, children }: any) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.6)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}
      onClick={onClose}>
      <div style={{ background: "#fff", borderRadius: 16, width: "90%", maxWidth: 440, overflow: "hidden" }} onClick={e => e.stopPropagation()}>
        <div style={{ background: "linear-gradient(135deg,#064e3b,#10b981)", padding: "18px 22px" }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{title}</div>
          {subtitle && <div style={{ fontSize: 12, color: "#a7f3d0", marginTop: 2 }}>{subtitle}</div>}
        </div>
        <div style={{ padding: 22 }}>{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children }: any) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 6 }}>{label}</label>
      {children}
    </div>
  );
}

function ModalActions({ onCancel, submitLabel }: any) {
  return (
    <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 4 }}>
      <button type="button" onClick={onCancel} style={{ padding: "9px 18px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", fontSize: 13, cursor: "pointer" }}>Batal</button>
      <button type="submit" style={{ padding: "9px 18px", borderRadius: 8, background: "#10b981", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>{submitLabel}</button>
    </div>
  );
}

const inp: React.CSSProperties = { width: "100%", padding: "9px 12px", border: "1px solid #d1d5db", borderRadius: 8, fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" };
