"use client";

import { useState } from "react";
import AuthLayout from "@/components/auth/AuthLayout";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    full_name: "",
    username: "",
    email: "",
    password: "",
    re_password: "",
    nik: "",
    phone: "",
    address: "",
  });

  const [showPass, setShowPass] = useState(false);
  const [showRePass, setShowRePass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  function update(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear field error on change
    if (fieldErrors[name]) setFieldErrors((prev) => { const n = { ...prev }; delete n[name]; return n; });
  }

  function validate() {
    const errs: Record<string, string> = {};
    if (!form.full_name.trim()) errs.full_name = "Nama lengkap wajib diisi";
    if (!form.username.trim()) errs.username = "Username wajib diisi";
    else if (form.username.length < 4) errs.username = "Username minimal 4 karakter";
    if (!form.email.trim()) errs.email = "Email wajib diisi";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Format email tidak valid";
    if (!form.password) errs.password = "Password wajib diisi";
    else if (form.password.length < 6) errs.password = "Password minimal 6 karakter";
    if (!form.re_password) errs.re_password = "Konfirmasi password wajib diisi";
    else if (form.password !== form.re_password) errs.re_password = "Password tidak cocok";
    if (form.nik && !/^\d{16}$/.test(form.nik)) errs.nik = "NIK harus 16 digit angka";
    if (form.phone && !/^[\d+\-]{8,15}$/.test(form.phone)) errs.phone = "Nomor HP tidak valid";
    return errs;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const errs = validate();
    if (Object.keys(errs).length > 0) { setFieldErrors(errs); return; }
    setFieldErrors({});
    setLoading(true);

    try {
      const formBody = new URLSearchParams();
      formBody.append("full_name", form.full_name.trim());
      formBody.append("username", form.username.trim());
      formBody.append("email", form.email.trim());
      formBody.append("password", form.password.trim());
      formBody.append("nik", form.nik.trim());
      formBody.append("phone", form.phone.trim());
      formBody.append("address", form.address.trim());

      const res = await fetch("/api/proxy/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formBody.toString(),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.message || errData.errors?.join(" ") || `Error: Status ${res.status}`);
        return;
      }

      const data = await res.json();
      if (data.success === false) {
        setError(data.message || data.errors?.join(" ") || "Gagal register");
        return;
      }

      router.push("/login");
    } catch (err: any) {
      setError(err?.message || "Tidak dapat terhubung ke server");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthLayout>
      <div className="form-wrap">
        <h1>Register Akun</h1>
        <p>Daftarkan petani / user baru</p>

        <form onSubmit={handleSubmit} noValidate>
          {/* Nama Lengkap */}
          <div className="field-group">
            <input
              name="full_name"
              placeholder="Nama Lengkap"
              value={form.full_name}
              onChange={update}
              className={fieldErrors.full_name ? "input-error" : ""}
            />
            {fieldErrors.full_name && <span className="field-err">{fieldErrors.full_name}</span>}
          </div>

          {/* Username */}
          <div className="field-group">
            <input
              name="username"
              placeholder="Username"
              value={form.username}
              onChange={update}
              className={fieldErrors.username ? "input-error" : ""}
            />
            {fieldErrors.username && <span className="field-err">{fieldErrors.username}</span>}
          </div>

          {/* Email */}
          <div className="field-group">
            <input
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={update}
              className={fieldErrors.email ? "input-error" : ""}
            />
            {fieldErrors.email && <span className="field-err">{fieldErrors.email}</span>}
          </div>

          {/* Password */}
          <div className="field-group">
            <div className="input-wrap">
              <input
                name="password"
                type={showPass ? "text" : "password"}
                placeholder="Password"
                value={form.password}
                onChange={update}
                className={fieldErrors.password ? "input-error" : ""}
              />
              <button type="button" className="eye-btn" onClick={() => setShowPass(!showPass)} tabIndex={-1}>
                {showPass ? "🙈" : "👁️"}
              </button>
            </div>
            {fieldErrors.password && <span className="field-err">{fieldErrors.password}</span>}
          </div>

          {/* Re-Password */}
          <div className="field-group">
            <div className="input-wrap">
              <input
                name="re_password"
                type={showRePass ? "text" : "password"}
                placeholder="Konfirmasi Password"
                value={form.re_password}
                onChange={update}
                className={fieldErrors.re_password ? "input-error" : ""}
              />
              <button type="button" className="eye-btn" onClick={() => setShowRePass(!showRePass)} tabIndex={-1}>
                {showRePass ? "🙈" : "👁️"}
              </button>
            </div>
            {fieldErrors.re_password && <span className="field-err">{fieldErrors.re_password}</span>}
          </div>

          <hr style={{ margin: "16px 0", borderColor: "#e2e8f0" }} />

          {/* NIK */}
          <div className="field-group">
            <input
              name="nik"
              placeholder="NIK (16 digit)"
              value={form.nik}
              onChange={update}
              maxLength={16}
              className={fieldErrors.nik ? "input-error" : ""}
            />
            {fieldErrors.nik && <span className="field-err">{fieldErrors.nik}</span>}
          </div>

          {/* No HP */}
          <div className="field-group">
            <input
              name="phone"
              placeholder="No HP"
              value={form.phone}
              onChange={update}
              className={fieldErrors.phone ? "input-error" : ""}
            />
            {fieldErrors.phone && <span className="field-err">{fieldErrors.phone}</span>}
          </div>

          {/* Alamat */}
          <div className="field-group">
            <textarea
              name="address"
              placeholder="Alamat"
              value={form.address}
              onChange={update}
              rows={3}
            />
          </div>

          {error && (
            <div className="error-box">⚠️ {error}</div>
          )}

          <button type="submit" disabled={loading} className="submit-btn">
            {loading ? "Mendaftarkan..." : "Register"}
          </button>
        </form>

        <p style={{ marginTop: 15, textAlign: "center", fontSize: 14, color: "#64748b" }}>
          Sudah punya akun?{" "}
          <button
            onClick={() => router.push("/login")}
            style={{ background: "none", border: "none", color: "#10b981", fontWeight: "bold", cursor: "pointer", fontSize: 14, padding: 0 }}
          >
            Login
          </button>
        </p>
      </div>

      <style jsx>{`
        .form-wrap { width: 100%; max-width: 420px; }
        h1 { font-size: 26px; color: #065f46; font-weight: 700; margin-bottom: 4px; }
        p { color: #64748b; margin-bottom: 16px; font-size: 14px; }
        .field-group { margin-bottom: 10px; }
        .input-wrap { position: relative; }
        .input-wrap input { padding-right: 40px; }
        .eye-btn {
          position: absolute; right: 10px; top: 50%; transform: translateY(-50%);
          background: none; border: none; cursor: pointer; font-size: 16px; padding: 2px;
        }
        input, textarea {
          width: 100%; padding: 10px 12px;
          border: 1px solid #d1d5db; border-radius: 8px;
          font-size: 14px; font-family: inherit; outline: none;
          transition: border-color 0.2s;
          box-sizing: border-box;
        }
        input:focus, textarea:focus { border-color: #10b981; box-shadow: 0 0 0 3px rgba(16,185,129,0.1); }
        input.input-error { border-color: #ef4444; }
        .field-err { font-size: 11px; color: #dc2626; margin-top: 3px; display: block; }
        .error-box {
          background: #fef2f2; border: 1px solid #fca5a5; border-radius: 8px;
          padding: 10px 14px; color: #b91c1c; font-size: 13px; margin-bottom: 12px;
        }
        .submit-btn {
          width: 100%; padding: 12px; background: #10b981; color: white;
          border: none; border-radius: 8px; font-weight: 600; font-size: 15px;
          cursor: pointer; margin-top: 8px; transition: background 0.2s;
        }
        .submit-btn:hover:not(:disabled) { background: #059669; }
        .submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }
      `}</style>
    </AuthLayout>
  );
}
