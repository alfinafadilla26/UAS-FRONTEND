import type { NextApiRequest, NextApiResponse } from 'next';

const BACKEND_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost/agriapp/api/web/v1';

// ── Mock Data (fallback kalau backend belum aktif) ─────────────────
const MOCK_LANDS = [
  { id: 1, land_name: "Lahan Babakan Sari", farmer_name: "Brahim", farmer_id: 1, commodity_name: "Kakao", commodity_id: 2, total_area_hectares: "22.98", latitude: -6.9147, longitude: 107.6098, has_polygon: true, polygon_path: JSON.stringify([[-6.913,107.608],[-6.913,107.612],[-6.916,107.612],[-6.916,107.608]]), eudr_status: "Compliant" },
  { id: 2, land_name: "Lahan Bos", farmer_name: "Brahim", farmer_id: 1, commodity_name: "Kakao", commodity_id: 2, total_area_hectares: "122.99", latitude: -6.9200, longitude: 107.6150, has_polygon: false, polygon_path: "[]", eudr_status: "Non-Compliant" },
  { id: 3, land_name: "Sawah Blok Utara", farmer_name: "Brahim", farmer_id: 1, commodity_name: "Kopi", commodity_id: 1, total_area_hectares: "12.35", latitude: -6.9080, longitude: 107.6200, has_polygon: true, polygon_path: JSON.stringify([[-6.907,107.619],[-6.907,107.622],[-6.910,107.622],[-6.910,107.619]]), eudr_status: "Non-Compliant" },
  { id: 4, land_name: "Lahan B4112", farmer_name: "Brahim", farmer_id: 1, commodity_name: "Kopi", commodity_id: 1, total_area_hectares: "46.00", latitude: -6.9250, longitude: 107.6050, has_polygon: false, polygon_path: "[]", eudr_status: "Non-Compliant" },
  { id: 5, land_name: "Kebun Karet Selatan", farmer_name: "Brahim", farmer_id: 1, commodity_name: "Karet", commodity_id: 3, total_area_hectares: "18.75", latitude: -6.9300, longitude: 107.6100, has_polygon: false, polygon_path: "[]", eudr_status: "Non-Compliant" },
];

const MOCK_COMMODITIES = [
  { id: 1, name: "Kopi", code: "KOPI" },
  { id: 2, name: "Kakao", code: "KAKAO" },
  { id: 3, name: "Karet", code: "KARET" },
  { id: 4, name: "Kelapa Sawit", code: "SAWIT" },
];

// Simpan perubahan polygon di memory (reset saat server restart)
const polygonStore: Record<number, string> = {};

function getMockResponse(path: string[], method: string, body: any): { status: number; data: any } | null {
  const route = path.join('/');

  // AUTH
  if (route === 'auth/login' && method === 'POST') {
    return { status: 200, data: { success: true, data: { access_token: 'mock_token_123', token_type: 'Bearer', expired_at: '2026-12-31', user: { id: 1, full_name: 'Brahim Santosa', username: 'brahim', email: 'brahim@agriapp.id', user_level: 'userfarmer' }, farmer: { id: 1, nik: '3204010101900001', phone: '081234567890', address: 'Bandung, Jawa Barat' } } } };
  }
  if (route === 'auth/register' && method === 'POST') {
    return { status: 200, data: { success: true, message: 'Registrasi berhasil' } };
  }

  // LAND list
  if ((route === 'land' || route === 'lands') && method === 'GET') {
    const lands = MOCK_LANDS.map(l => ({
      ...l,
      polygon_path: polygonStore[l.id] ?? l.polygon_path,
      has_polygon: polygonStore[l.id] ? JSON.parse(polygonStore[l.id]).length > 0 : l.has_polygon,
    }));
    return { status: 200, data: { success: true, data: lands } };
  }

  // LAND detail
  const landDetailMatch = route.match(/^land\/(\d+)$/) || route.match(/^lands\/(\d+)$/);
  if (landDetailMatch && method === 'GET') {
    const id = parseInt(landDetailMatch[1]);
    const land = MOCK_LANDS.find(l => l.id === id);
    if (!land) return { status: 404, data: { success: false, message: 'Lahan tidak ditemukan' } };
    return { status: 200, data: { success: true, data: { ...land, polygon_path: polygonStore[id] ?? land.polygon_path } } };
  }

  // LAND create
  if ((route === 'land/create' || route === 'land') && method === 'POST') {
    const newId = MOCK_LANDS.length + Date.now() % 1000;
    return { status: 200, data: { success: true, message: 'Lahan berhasil ditambahkan', data: { id: newId } } };
  }

  // LAND update
  const landUpdateMatch = route.match(/^land\/update\/(\d+)$/) || route.match(/^land\/(\d+)\/update$/);
  if (landUpdateMatch && (method === 'POST' || method === 'PUT')) {
    return { status: 200, data: { success: true, message: 'Lahan berhasil diperbarui' } };
  }

  // LAND delete
  const landDeleteMatch = route.match(/^land\/delete\/(\d+)$/) || route.match(/^land\/(\d+)\/delete$/);
  if (landDeleteMatch && method === 'POST') {
    return { status: 200, data: { success: true, message: 'Lahan berhasil dihapus' } };
  }

  // POLYGON save
  const polygonSaveMatch = route.match(/^land-polygon\/save\/(\d+)$/) || route.match(/^polygon\/save\/(\d+)$/) || route.match(/^land\/(\d+)\/polygon/);
  if (polygonSaveMatch && (method === 'POST' || method === 'PUT')) {
    const id = parseInt(polygonSaveMatch[1]);
    const coords = body?.polygon_path || body?.coordinates || body?.coords || '[]';
    polygonStore[id] = typeof coords === 'string' ? coords : JSON.stringify(coords);
    return { status: 200, data: { success: true, message: 'Polygon berhasil disimpan' } };
  }

  // EUDR check
  const eudrMatch = route.match(/^eudr\/check\/(\d+)$/) || route.match(/^land\/(\d+)\/eudr/);
  if (eudrMatch) {
    const id = parseInt(eudrMatch[1]);
    const polyPath = polygonStore[id] ?? (MOCK_LANDS.find(l => l.id === id)?.polygon_path || '[]');
    const hasPoly = JSON.parse(polyPath).length > 0;
    return { status: 200, data: { success: true, data: { land_id: id, is_compliant: hasPoly, eudr_status: hasPoly ? 'Compliant' : 'Non-Compliant', checked_at: new Date().toISOString(), message: hasPoly ? 'Lahan ini comply dengan regulasi EUDR' : 'Lahan belum dipetakan polygon-nya' } } };
  }

  // COMMODITIES
  if (route === 'commodity' || route === 'commodities') {
    return { status: 200, data: { success: true, data: MOCK_COMMODITIES } };
  }

  // PROFILE update
  if ((route === 'profile/update' || route === 'user/update') && method === 'POST') {
    return { status: 200, data: { success: true, message: 'Profil berhasil diperbarui' } };
  }

  // PROFILE change-password
  if (route === 'profile/change-password' && method === 'POST') {
    return { status: 200, data: { success: true, message: 'Password berhasil diubah' } };
  }

  // LAND DOCUMENTS
  if (route === 'land-documents' && method === 'GET') {
    return { status: 200, data: { success: true, data: {} } };
  }
  if (route === 'land-documents/create' && method === 'POST') {
    return { status: 200, data: { success: true, message: 'Dokumen ditambahkan' } };
  }

  // PLANTING CYCLES
  if (route === 'planting-cycles' && method === 'GET') {
    return { status: 200, data: { success: true, data: {} } };
  }

  return null; // tidak ada mock untuk route ini
}

function buildTargetUrl(pathSegments: string[] | string, query: any) {
  const path = Array.isArray(pathSegments) ? pathSegments.join('/') : String(pathSegments || '');
  const url = new URL(`${BACKEND_BASE}/${path}`);
  for (const key of Object.keys(query || {})) {
    if (key === 'path') continue;
    const val = query[key];
    if (Array.isArray(val)) val.forEach((v) => url.searchParams.append(key, String(v)));
    else if (val != null) url.searchParams.append(key, String(val));
  }
  return url.toString();
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const pathSegments = (req.query.path || []) as string[];
  const method = req.method || 'GET';

  console.log(`🔥 PROXY: ${method} /${pathSegments.join('/')}`);

  // 1. Coba forward ke backend asli
  try {
    const target = buildTargetUrl(pathSegments, req.query);
    const forwardHeaders: Record<string, string> = {};
    for (const [k, v] of Object.entries(req.headers)) {
      const key = k.toLowerCase();
      if (!v || ['host','origin','referer','connection'].includes(key)) continue;
      forwardHeaders[key] = Array.isArray(v) ? v.join(',') : String(v);
    }

    let body: any = undefined;
    if (method !== 'GET' && method !== 'HEAD') {
      const ct = (req.headers['content-type'] || '').toString();
      if (ct.includes('application/json')) body = JSON.stringify(req.body ?? {});
      else if (ct.includes('application/x-www-form-urlencoded')) {
        body = typeof req.body === 'string' ? req.body : new URLSearchParams(req.body as any).toString();
      } else {
        try { body = JSON.stringify(req.body ?? {}); } catch { body = undefined; }
      }
    }

    const resp = await fetch(target, { method, headers: forwardHeaders, body, signal: AbortSignal.timeout(5000) });

    // Kalau backend return 500/4xx, coba mock dulu
    if (resp.status >= 500) {
      throw new Error(`Backend returned ${resp.status}`);
    }

    res.status(resp.status);
    const ct = resp.headers.get('content-type');
    if (ct) res.setHeader('content-type', ct);
    res.send(Buffer.from(await resp.arrayBuffer()));
    return;

  } catch (err: any) {
    console.warn(`⚠️  Backend tidak tersedia (${err?.message}), menggunakan mock data...`);
  }

  // 2. Fallback ke mock data
  const mock = getMockResponse(pathSegments, method, req.body);
  if (mock) {
    console.log(`✅ Mock response untuk /${pathSegments.join('/')}`);
    res.status(mock.status).json(mock.data);
    return;
  }

  // 3. Tidak ada mock → kembalikan error yang informatif
  console.error(`❌ Tidak ada mock untuk: ${method} /${pathSegments.join('/')}`);
  res.status(503).json({
    success: false,
    message: `Endpoint /${pathSegments.join('/')} belum tersedia. Backend offline & belum ada mock data untuk route ini.`,
    hint: 'Tambahkan mock di pages/api/proxy/[...path].ts fungsi getMockResponse()',
  });
}

export const config = { api: { bodyParser: true } };
